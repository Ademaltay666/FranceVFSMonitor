# France VFS Takip — Android kaynak projesi

## Ne yapar?
- Resmî VFS Türkiye/Fransa bilgilendirme sayfasını yaklaşık 4 saatte bir kontrol eder.
- İçerik özeti değişirse Android bildirimi verir.
- CAPTCHA, erişim engeli, boş yanıt veya ağ hatasını randevu varmış gibi değerlendirmez.
- CAPTCHA/erişim kontrollerini aşmaya çalışmaz.

## Önemli sınırlamalar
- Bu yalnızca genel VFS sayfasını izleyen bir başlangıç projesidir. Giriş gerektiren randevu ekranını izlemez ve gerçek randevu müsaitliğini tespit edemez.
- Sayfa değişikliği randevu açıldığı anlamına gelmez; yanlış alarmı önlemek için bildirim metni bunu açıkça belirtir.
- Android WorkManager zamanlaması pil optimizasyonu ve işletim sistemi nedeniyle kesin saatlerde çalışmayabilir.
- Telefon bildirimi dahildir. E-posta uygulamasını açan bir buton vardır, ancak otomatik e-posta gönderimi bu örnekte uygulanmamıştır. Otomatik e-posta için SMTP parolası gibi sırları APK içine koymak güvenli değildir; güvenli bir sunucu/servis gerekir.
- Bu proje örnek kaynak koddur; burada derlenmiş APK sunulmuyor.

## Derleme
1. Bilgisayara Android Studio kurun.
2. Bu klasörü Android Studio ile açın.
3. Gradle senkronizasyonunu tamamlayın.
4. `Build > Build APK(s)` seçin.
5. Android Studio'nun oluşturduğu APK'yı kendi telefonunuza yükleyin.
6. Uygulamayı açıp bildirim iznini verin ve “Takibi başlat / zamanla” düğmesine basın.

## Resmî adres
https://www.vfsglobal.com/france/turkey/french/index.html
