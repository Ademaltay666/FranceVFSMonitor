package com.example.francevfsmonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val officialUrl = "https://www.vfsglobal.com/france/turkey/french/index.html"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        val prefs = getSharedPreferences("monitor", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
        }
        fun text(value: String, size: Float = 16f): TextView =
            TextView(this).apply { text = value; textSize = size; setPadding(0, 0, 0, 24) }
        fun button(label: String, action: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { action() } }

        layout.addView(text("France VFS Takip", 25f))
        layout.addView(text(
            "Bu uygulama VFS'nin herkese açık ana sayfasını yaklaşık 4 saatte bir kontrol eder " +
            "(günde yaklaşık 6 kez; Android zamanlaması kesin saat garantisi vermez). " +
            "Sayfa değişirse bildirim verir; değişiklik, randevu bulunduğu anlamına GELMEZ."
        ))
        layout.addView(text("CAPTCHA veya erişim engeli çıkarsa aşmaya çalışmaz. Bu proje, giriş gerektiren randevu ekranının müsaitliğini doğrulayamaz."))
        layout.addView(button("Takibi başlat / zamanla") {
            val request = PeriodicWorkRequestBuilder<VfsCheckWorker>(4, TimeUnit.HOURS)
                .addTag("vfs_monitor")
                .build()
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "vfs_periodic_check",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
            prefs.edit().putBoolean("enabled", true).apply()
            StatusNotifier.show(this, "Takip etkinleştirildi", "VFS ana sayfası yaklaşık 4 saatte bir kontrol edilecek.")
        })
        layout.addView(button("Takibi durdur") {
            WorkManager.getInstance(this).cancelUniqueWork("vfs_periodic_check")
            prefs.edit().putBoolean("enabled", false).apply()
            StatusNotifier.show(this, "Takip durduruldu", "Otomatik kontroller durduruldu.")
        })
        layout.addView(button("VFS sitesini aç") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(officialUrl)))
        })
        layout.addView(button("E-posta uygulamasını aç") {
            val email = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_SUBJECT, "Fransa VFS randevu takibi")
                putExtra(Intent.EXTRA_TEXT,
                    "VFS takip uygulaması hakkında notlarımı buraya yazacağım.\n\n" +
                    "Not: Bu buton e-posta uygulamasını açar; otomatik e-posta göndermez.")
            }
            startActivity(Intent.createChooser(email, "E-posta uygulaması seç"))
        })
        layout.addView(text(
            "E-posta: Bu örnek otomatik e-posta göndermez. Bunun güvenli şekilde yapılması için " +
            "şifreyi APK içine koymayan bir e-posta sunucusu/servisi gerekir. Şimdilik sayfa değişikliği " +
            "telefon bildirimi olarak gelir; e-posta uygulaması elle açılabilir."
        ))
        setContentView(layout)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }
}
