package com.example.francevfsmonitor

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class VfsCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val url = "https://www.vfsglobal.com/france/turkey/french/index.html"
    private val client = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "FranceVFSMonitor/1.0 (user-initiated public-page change monitor)")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    // Do not treat errors, blocks, or CAPTCHA pages as appointment availability.
                    return@withContext Result.retry()
                }
                val body = response.body?.string().orEmpty()
                if (body.isBlank() ||
                    body.contains("captcha", ignoreCase = true) ||
                    body.contains("verify you are human", ignoreCase = true) ||
                    body.contains("access denied", ignoreCase = true) ||
                    body.contains("robot", ignoreCase = true)
                ) {
                    // Respect access controls. No attempt is made to bypass them.
                    return@withContext Result.success()
                }

                val digest = MessageDigest.getInstance("SHA-256")
                    .digest(body.toByteArray())
                    .joinToString("") { "%02x".format(it) }

                val prefs = applicationContext.getSharedPreferences("monitor", Context.MODE_PRIVATE)
                val previous = prefs.getString("last_hash", null)
                prefs.edit().putString("last_hash", digest).apply()

                if (previous != null && previous != digest) {
                    StatusNotifier.show(
                        applicationContext,
                        "VFS sayfası değişti",
                        "Sayfada bir değişiklik algılandı. Bu, randevu açıldığı anlamına gelmez; VFS sitesini kendin kontrol et."
                    )
                }
                Result.success()
            }
        } catch (_: Exception) {
            // Network problems are not interpreted as availability.
            Result.retry()
        }
    }
}
